# Aetheris AI — Institutional Crypto Intelligence Terminal

Aetheris AI is an institutional-grade quantitative crypto & macro market intelligence terminal built with React 19, TypeScript, Tailwind CSS, Express, and Google Gemini AI.

---

## ⚡ Key Features

- **Live Market Radar**: Real-time ticker feeds, 24h gainers/losers, global market metrics, macroeconomic breaking news, and global session clocks (Tokyo, London, New York, Sydney).
- **Multi-Lane Technical Analysis**: Interactive candlestick & depth charts, RSI / MACD / Bollinger overlay toggles, order flow heatmaps, and one-click AI Market Diagnostics.
- **AI Copilot & Quant Community**: Real-time institutional quant assistant powered by `@google/genai` (Gemini 3.8 Flash), paired with active alpha discussion channels.
- **Algorithmic Automations**: Strategy builder with automated signal backtesting, win rate calculation, PnL analytics, and trigger management.
- **Role-Based Access Control (RBAC)**:
  - **Owner Tier** (`harshitggupta52@gmail.com`): Master admin access with unlimited tokens, unrestricted algorithmic triggers, and full terminal control.
  - **Pro Tier**: 50,000 AI tokens/month, automated alerts, and custom indicators.
  - **Free Tier**: Read-only baseline access with interactive upgrade modals.

---

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide React, Motion
- **Backend / API**: Express, Vite middleware, Node.js (`tsx`)
- **AI Engine**: `@google/genai` SDK (Gemini 3.8 Flash)
- **Bundler**: Vite 6, esbuild

---

## 🚀 Getting Started

### 1. Clone or Extract
```bash
cd aetheris-ai
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment Variables
Create a `.env` file based on `.env.example`:
```bash
cp .env.example .env
```
Add your Gemini API key (optional for core features, required for live AI endpoints):
```env
GEMINI_API_KEY=your_gemini_api_key_here
```

### 4. Run Development Server
```bash
npm run dev
```
The terminal will be accessible at `http://localhost:3000`.

### 5. Production Build
```bash
npm run build
npm start
```

---

## 📦 Pushing to GitHub

To push this project to a new repository on your GitHub account:

```bash
# 1. Initialize git
git init

# 2. Stage all files (respecting .gitignore)
git add .

# 3. Commit the code
git commit -m "Initial commit: Aetheris AI Crypto Intelligence Terminal"

# 4. Set main branch
git branch -M main

# 5. Connect your GitHub remote repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/aetheris-ai.git

# 6. Push to GitHub
git push -u origin main
```

---

## 📄 License
MIT License. Built with Google AI Studio.
