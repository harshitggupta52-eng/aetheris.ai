export type UserRole = 'owner' | 'free' | 'pro';

export interface UserProfile {
  name: string;
  email: string;
  avatarLetter: string;
  role: UserRole;
  tokens: number; // For owner, displayed as ∞
  deltaIdVerified?: boolean;
}

export interface CryptoTicker {
  symbol: string;
  pair: string;
  name: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: string;
}

export interface Candle {
  time: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface NewsStory {
  id: string;
  source: string;
  timeAgo: string;
  title: string;
  snippet: string;
  sentiment: 'Bullish' | 'Neutral' | 'Bearish';
  category: string;
  readTime: string;
}

export interface TradingSession {
  id: string;
  name: string;
  city: string;
  status: 'open' | 'closed';
  openTimeUTC: string;
  closeTimeUTC: string;
  opensIn?: string;
  closesIn?: string;
}

export interface AiAnalysisLane {
  title: string;
  status: string;
  details: string;
}

export interface TheCall {
  bias: 'LONG' | 'SHORT' | 'NEUTRAL_WAIT';
  headline: string;
  summary: string;
  entryZone: string;
  target: string;
  stopLoss: string;
  riskReward: string;
  confidence: number;
}

export interface AiChartAnalysis {
  lane1: AiAnalysisLane;
  lane2: AiAnalysisLane;
  lane3: AiAnalysisLane;
  lane4: AiAnalysisLane;
  theCall: TheCall;
}

export interface TradingStrategy {
  id: string;
  name: string;
  author: string;
  tagline: string;
  indicator: string;
  winRate: number;
  apy: number;
  tradesCount: number;
  profitFactor: number;
  isProOnly: boolean;
  isActive: boolean;
  createdAt: string;
}

export interface CopilotMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedPrompts?: string[];
}
