import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { RadarView } from './components/RadarView';
import { AnalyzeView } from './components/AnalyzeView';
import { CommunityView } from './components/CommunityView';
import { AutomateView } from './components/AutomateView';
import { ProfileView } from './components/ProfileView';
import { UpgradeModal } from './components/UpgradeModal';
import { UserProfile, UserRole, CryptoTicker } from './types';
import { INITIAL_TICKERS, INITIAL_SESSIONS, INITIAL_NEWS } from './data/mockData';

const OWNER_EMAIL = 'harshitggupta52@gmail.com';

export default function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [activeTab, setActiveTab] = useState<TabType>('radar');
  const [selectedSymbol, setSelectedSymbol] = useState<string>('BTC');
  const [tickers, setTickers] = useState<CryptoTicker[]>(INITIAL_TICKERS);
  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);

  // User Profile: Default as Owner for Free, as requested
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('aetheris_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return {
      name: 'Virat gupta',
      email: OWNER_EMAIL,
      avatarLetter: 'V',
      role: 'owner',
      tokens: 999999,
      deltaIdVerified: false,
    };
  });

  // Save user profile state
  useEffect(() => {
    localStorage.setItem('aetheris_user', JSON.stringify(user));
  }, [user]);

  // Subtle real-time price fluctuation simulation for tickers
  useEffect(() => {
    const interval = setInterval(() => {
      setTickers((prev) =>
        prev.map((t) => {
          const delta = (Math.random() - 0.49) * (t.price * 0.0004);
          const newPrice = parseFloat((t.price + delta).toFixed(2));
          return {
            ...t,
            price: newPrice,
          };
        })
      );
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Role Switcher / Simulator
  const handleUpdateRole = (role: UserRole) => {
    if (role === 'owner') {
      setUser((prev) => ({
        ...prev,
        role: 'owner',
        tokens: 999999,
      }));
    } else if (role === 'free') {
      setUser((prev) => ({
        ...prev,
        role: 'free',
        tokens: 0, // Paywall active
      }));
    } else if (role === 'pro') {
      setUser((prev) => ({
        ...prev,
        role: 'pro',
        tokens: 250,
      }));
    }
  };

  // Consume token handler
  const handleConsumeToken = (cost: number): boolean => {
    if (user.role === 'owner') {
      // Owner is 100% free with unlimited tokens!
      return true;
    }
    if (user.tokens >= cost) {
      setUser((prev) => ({
        ...prev,
        tokens: Math.max(0, prev.tokens - cost),
      }));
      return true;
    }
    return false;
  };

  // Select Plan from Upgrade Modal
  const handleSelectPlan = (role: UserRole, tokensToAdd: number) => {
    setUser((prev) => ({
      ...prev,
      role,
      tokens: (prev.role === 'owner' ? 999999 : prev.tokens) + tokensToAdd,
    }));
  };

  const handleSelectCoin = (symbol: string) => {
    setSelectedSymbol(symbol);
    setActiveTab('analyze');
  };

  return (
    <div
      className={`min-h-screen ${
        theme === 'dark'
          ? 'bg-[#0b0f17] text-slate-100'
          : 'bg-[#f4f7fb] text-slate-900'
      } font-sans selection:bg-cyan-500/30 selection:text-cyan-200 transition-colors duration-200`}
    >
      {/* Top Header with brand name 'Aetheris AI' and owner VIP controls */}
      <Header
        user={user}
        onUpdateRole={handleUpdateRole}
        onOpenUpgrade={() => setIsUpgradeOpen(true)}
        theme={theme}
        onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      />

      {/* Main View Container */}
      <main className="max-w-4xl mx-auto">
        {activeTab === 'radar' && (
          <RadarView
            tickers={tickers}
            sessions={INITIAL_SESSIONS}
            news={INITIAL_NEWS}
            user={user}
            onSelectCoin={handleSelectCoin}
            onConsumeToken={handleConsumeToken}
            onOpenUpgrade={() => setIsUpgradeOpen(true)}
          />
        )}

        {activeTab === 'analyze' && (
          <AnalyzeView
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            tickers={tickers}
            user={user}
            onConsumeToken={handleConsumeToken}
            onOpenUpgrade={() => setIsUpgradeOpen(true)}
          />
        )}

        {activeTab === 'copilot' && (
          <CommunityView
            user={user}
            onConsumeToken={handleConsumeToken}
            onOpenUpgrade={() => setIsUpgradeOpen(true)}
          />
        )}

        {activeTab === 'automate' && (
          <AutomateView
            user={user}
            onOpenUpgrade={() => setIsUpgradeOpen(true)}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            user={user}
            onUpdateRole={handleUpdateRole}
            onOpenUpgrade={() => setIsUpgradeOpen(true)}
            theme={theme}
            onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          />
        )}
      </main>

      {/* Sticky Bottom Navigation Bar */}
      <BottomNav activeTab={activeTab} onChangeTab={setActiveTab} />

      {/* Upgrade Pro Modal for Paid Tiers */}
      <UpgradeModal
        isOpen={isUpgradeOpen}
        onClose={() => setIsUpgradeOpen(false)}
        onSelectPlan={handleSelectPlan}
        currentRole={user.role}
      />
    </div>
  );
}
