import React, { useState } from 'react';
import { Sparkles, Sun, Moon, ShieldCheck, ChevronDown, Check, Coins, Download, FolderArchive } from 'lucide-react';
import { UserProfile, UserRole } from '../types';

interface HeaderProps {
  user: UserProfile;
  onUpdateRole: (role: UserRole) => void;
  onOpenUpgrade: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  onUpdateRole,
  onOpenUpgrade,
  theme,
  onToggleTheme,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0b0f17]/95 backdrop-blur-md border-b border-slate-800/80 px-4 py-3">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        {/* Brand Logo & Name (not deeepr.ai -> Aetheris AI) */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-500/40 text-cyan-400 shadow-sm shadow-cyan-500/10">
            {/* Minimalist 3-bar algorithmic quantum icon */}
            <div className="flex items-end gap-1 h-4">
              <span className="w-1 h-2.5 bg-cyan-400 rounded-xs"></span>
              <span className="w-1 h-4 bg-cyan-300 rounded-xs shadow-[0_0_8px_rgba(34,211,238,0.8)]"></span>
              <span className="w-1 h-3 bg-cyan-500 rounded-xs"></span>
            </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-tight text-white text-[15px] sm:text-base font-mono">
                aetheris<span className="text-cyan-400">.ai</span>
              </span>
              <span className="px-1.5 py-0.2 text-[9px] font-semibold uppercase tracking-wider rounded bg-slate-800 text-cyan-400 border border-slate-700/60">
                BETA
              </span>
            </div>
          </div>
        </div>

        {/* Right side controls: Theme, Tokens chip, User status dropdown */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Direct ZIP download for GitHub */}
          <a
            id="header-download-zip-btn"
            href="/aetheris-ai.zip"
            download="aetheris-ai-terminal.zip"
            title="Download Project ZIP for GitHub"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-750 border border-slate-700/60 text-cyan-300 hover:text-white transition-all shadow-sm group"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400 group-hover:translate-y-0.5 transition-transform" />
            <span className="font-mono text-[11px] font-semibold">ZIP</span>
          </a>

          {/* Theme toggle button */}
          <button
            id="theme-toggle-btn"
            onClick={onToggleTheme}
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
            className="w-8 h-8 rounded-lg flex items-center justify-center bg-slate-800/80 hover:bg-slate-750 border border-slate-700/60 text-slate-300 hover:text-white transition-colors"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400/90" />
            ) : (
              <Moon className="w-4 h-4 text-cyan-400" />
            )}
          </button>

          {/* Token chip matching screenshot ($ 0 or tokens) */}
          <button
            id="tokens-chip-btn"
            onClick={() => {
              if (user.role !== 'owner') {
                onOpenUpgrade();
              }
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono font-medium border transition-all ${
              user.role === 'owner'
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                : user.tokens > 0
                ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
                : 'bg-slate-800/80 border-slate-700/70 text-slate-400'
            }`}
          >
            {user.role === 'owner' ? (
              <>
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-bold">∞ VIP</span>
              </>
            ) : (
              <>
                <span className="w-3.5 h-3.5 rounded-full border border-amber-400/60 text-amber-400 flex items-center justify-center text-[10px] font-bold">
                  $
                </span>
                <span>{user.tokens}</span>
              </>
            )}
          </button>

          {/* User Account / Role Pill with dropdown */}
          <div className="relative">
            <button
              id="user-profile-menu-btn"
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-1.5 bg-slate-800/90 hover:bg-slate-750 border border-slate-700/80 pl-1.5 pr-2.5 py-1 rounded-full text-xs font-medium text-slate-200 transition-colors"
            >
              <div className="w-5 h-5 rounded-full bg-cyan-600 flex items-center justify-center text-white font-bold text-[11px]">
                {user.avatarLetter}
              </div>
              <span className="font-semibold uppercase tracking-wider text-[10px]">
                {user.role === 'owner' ? 'OWNER (FREE)' : user.role === 'pro' ? 'PRO' : 'FREE'}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {/* Dropdown for role switching / owner controls */}
            {dropdownOpen && (
              <div
                id="user-role-dropdown"
                className="absolute right-0 mt-2 w-64 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-50 text-xs"
              >
                <div className="px-2.5 py-2 border-b border-slate-800/80 mb-1">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-cyan-600 flex items-center justify-center text-white font-bold text-xs">
                      {user.avatarLetter}
                    </div>
                    <div className="truncate">
                      <p className="font-semibold text-white truncate">{user.name}</p>
                      <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                    </div>
                  </div>
                  {user.role === 'owner' && (
                    <div className="mt-2 inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-medium">
                      <ShieldCheck className="w-3 h-3 text-amber-400" />
                      Platform Owner (Lifetime Free VIP)
                    </div>
                  )}
                </div>

                <div className="px-2 py-1 text-[10px] uppercase font-semibold text-slate-400">
                  Role Simulator (Owner Feature)
                </div>

                <button
                  onClick={() => {
                    onUpdateRole('owner');
                    setDropdownOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between transition-colors ${
                    user.role === 'owner'
                      ? 'bg-amber-500/20 text-amber-200 font-medium'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400">👑</span>
                    <div>
                      <p className="font-medium text-slate-200">Owner / Founder</p>
                      <p className="text-[10px] text-slate-400">100% Free · Unlimited Tokens</p>
                    </div>
                  </div>
                  {user.role === 'owner' && <Check className="w-4 h-4 text-amber-400" />}
                </button>

                <button
                  onClick={() => {
                    onUpdateRole('free');
                    setDropdownOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between transition-colors ${
                    user.role === 'free'
                      ? 'bg-cyan-500/20 text-cyan-200 font-medium'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">👤</span>
                    <div>
                      <p className="font-medium text-slate-200">Free Visitor</p>
                      <p className="text-[10px] text-slate-400">0 Tokens · Paywall active</p>
                    </div>
                  </div>
                  {user.role === 'free' && <Check className="w-4 h-4 text-cyan-400" />}
                </button>

                <button
                  onClick={() => {
                    onUpdateRole('pro');
                    setDropdownOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between transition-colors ${
                    user.role === 'pro'
                      ? 'bg-blue-500/20 text-blue-200 font-medium'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-400">⚡</span>
                    <div>
                      <p className="font-medium text-slate-200">Paid Pro Member</p>
                      <p className="text-[10px] text-slate-400">$29/mo · 250 Tokens</p>
                    </div>
                  </div>
                  {user.role === 'pro' && <Check className="w-4 h-4 text-cyan-400" />}
                </button>

                <div className="pt-2 mt-1 border-t border-slate-800 space-y-1">
                  <a
                    href="/aetheris-ai.zip"
                    download="aetheris-ai-terminal.zip"
                    onClick={() => setDropdownOpen(false)}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between text-cyan-400 hover:bg-slate-800 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <Download className="w-3.5 h-3.5" />
                      <span className="font-medium text-[11px]">Download ZIP for GitHub</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">.zip</span>
                  </a>

                  {user.role === 'free' && (
                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        onOpenUpgrade();
                      }}
                      className="w-full py-1.5 px-3 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold text-xs text-center shadow-md hover:opacity-95 transition-opacity"
                    >
                      Upgrade to Pro
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
