import React, { useState } from 'react';
import { Plus, Lock, Upload, Trophy, Layers, CheckCircle2, Play, Pause, Sparkles, TrendingUp, Sliders, X } from 'lucide-react';
import { TradingStrategy, UserProfile } from '../types';
import { TOP_STRATEGIES } from '../data/mockData';

interface AutomateViewProps {
  user: UserProfile;
  onOpenUpgrade: () => void;
  onSelectStrategyOnChart?: (strategy: TradingStrategy) => void;
}

export const AutomateView: React.FC<AutomateViewProps> = ({
  user,
  onOpenUpgrade,
  onSelectStrategyOnChart,
}) => {
  const [activeTab, setActiveTab] = useState<'my' | 'top'>('my');
  const [myStrategies, setMyStrategies] = useState<TradingStrategy[]>([]);
  const [topStrategies, setTopStrategies] = useState<TradingStrategy[]>(TOP_STRATEGIES);
  const [showNewModal, setShowNewModal] = useState(false);

  // New Strategy Form state
  const [newStratName, setNewStratName] = useState('BTC Volatility Reversion');
  const [newPair, setNewPair] = useState('BTC/USDT');
  const [newIndicator, setNewIndicator] = useState('RSI Oversold (< 30) + EMA 20 Reclaim');
  const [newTp, setNewTp] = useState(2.8);
  const [newSl, setNewSl] = useState(1.1);
  const [backtesting, setBacktesting] = useState(false);
  const [backtestResult, setBacktestResult] = useState<{
    winRate: number;
    trades: number;
    profitFactor: number;
    apy: number;
  } | null>(null);

  const handleRunBacktest = () => {
    setBacktesting(true);
    setTimeout(() => {
      setBacktestResult({
        winRate: 71.4,
        trades: 342,
        profitFactor: 2.65,
        apy: 132.8,
      });
      setBacktesting(false);
    }, 1000);
  };

  const handleSaveStrategy = () => {
    const newStrat: TradingStrategy = {
      id: `strat-${Date.now()}`,
      name: newStratName,
      author: user.name,
      tagline: `Automated ${newPair} trigger based on ${newIndicator}. TP: ${newTp}%, SL: ${newSl}%.`,
      indicator: newIndicator,
      winRate: backtestResult ? backtestResult.winRate : 68.5,
      apy: backtestResult ? backtestResult.apy : 115.0,
      tradesCount: backtestResult ? backtestResult.trades : 180,
      profitFactor: backtestResult ? backtestResult.profitFactor : 2.4,
      isProOnly: false,
      isActive: true,
      createdAt: 'Just now',
    };

    setMyStrategies((prev) => [newStrat, ...prev]);
    setShowNewModal(false);
    setBacktestResult(null);
  };

  const toggleStrategyActive = (id: string, isMy: boolean) => {
    if (isMy) {
      setMyStrategies((prev) =>
        prev.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s))
      );
    } else {
      setTopStrategies((prev) =>
        prev.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s))
      );
    }
  };

  const isLockedForUser = user.role === 'free';

  return (
    <div className="space-y-4 pb-24 max-w-2xl mx-auto px-4 pt-2">
      {/* Subheader matching Screenshot 4 */}
      <div className="bg-[#121926] border border-slate-800 rounded-2xl p-4 shadow-lg space-y-3">
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">
          Pick a strategy that is already working. Tap one to see its trades on the chart.
        </p>

        {/* 2x2 Action Buttons matching Screenshot 4 */}
        <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
          {/* + New Button */}
          <button
            id="new-strategy-btn"
            onClick={() => setShowNewModal(true)}
            className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-cyan-400" />
            <span>+ New</span>
          </button>

          {/* Import Button */}
          <button
            id="import-strategy-btn"
            onClick={() => {
              if (isLockedForUser) {
                onOpenUpgrade();
              } else {
                alert('Strategy import dialog ready: upload .json strategy configuration.');
              }
            }}
            className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            {isLockedForUser ? (
              <Lock className="w-3.5 h-3.5 text-amber-400/80" />
            ) : (
              <Upload className="w-3.5 h-3.5 text-cyan-400" />
            )}
            <span>Import</span>
          </button>

          {/* Top Performers Button */}
          <button
            id="top-performers-btn"
            onClick={() => {
              if (isLockedForUser) {
                onOpenUpgrade();
              } else {
                setActiveTab('top');
              }
            }}
            className={`py-2.5 px-3 rounded-xl border font-semibold flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'top'
                ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-400'
            }`}
          >
            {isLockedForUser ? (
              <Lock className="w-3.5 h-3.5 text-amber-400/80" />
            ) : (
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span>Top performers</span>
          </button>

          {/* My Strategies Button */}
          <button
            id="my-strategies-btn"
            onClick={() => setActiveTab('my')}
            className={`py-2.5 px-3 rounded-xl border font-semibold flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'my'
                ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-300'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>My strategies</span>
          </button>
        </div>
      </div>

      {/* Main content depending on active tab */}
      {activeTab === 'my' ? (
        myStrategies.length === 0 ? (
          /* Empty state matching Screenshot 4 italic text */
          <div className="bg-[#121926] border border-slate-800 rounded-2xl p-8 text-center space-y-3 shadow-lg">
            <p className="text-xs text-slate-400 italic">
              Nothing here yet. Pick a top performer, or press New to build your own.
            </p>
            <button
              onClick={() => setShowNewModal(true)}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs transition-colors shadow-md"
            >
              Build your first strategy
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {myStrategies.map((strat) => (
              <div
                key={strat.id}
                className="bg-[#121926] border border-slate-800 rounded-2xl p-4 space-y-2 shadow-lg"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white">{strat.name}</h3>
                    <p className="text-[11px] text-slate-400">{strat.tagline}</p>
                  </div>
                  <button
                    onClick={() => toggleStrategyActive(strat.id, true)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                      strat.isActive
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {strat.isActive ? <Play className="w-3 h-3 fill-emerald-400" /> : <Pause className="w-3 h-3" />}
                    <span>{strat.isActive ? 'Active' : 'Paused'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-[11px] font-mono">
                  <div className="bg-slate-900 p-2 rounded-lg">
                    <span className="text-slate-400 block text-[10px]">Win Rate</span>
                    <span className="font-bold text-emerald-400">{strat.winRate}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg">
                    <span className="text-slate-400 block text-[10px]">Backtest APY</span>
                    <span className="font-bold text-cyan-300">{strat.apy}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg">
                    <span className="text-slate-400 block text-[10px]">Profit Factor</span>
                    <span className="font-bold text-white">{strat.profitFactor}x</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        /* Top Performers list */
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Verified Quant Algorithms
            </h2>
            <span className="text-[11px] font-mono text-cyan-400">Audited 15M / 1H Live</span>
          </div>

          {topStrategies.map((strat) => (
            <div
              key={strat.id}
              className="bg-[#121926] border border-slate-800 rounded-2xl p-4 space-y-2.5 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-white">{strat.name}</h3>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                      {strat.author}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{strat.tagline}</p>
                </div>

                <button
                  onClick={() => toggleStrategyActive(strat.id, false)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    strat.isActive
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {strat.isActive ? <Play className="w-3 h-3 fill-emerald-400" /> : <Play className="w-3 h-3" />}
                  <span>{strat.isActive ? 'Executing' : 'Deploy'}</span>
                </button>
              </div>

              <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-800/80 text-[11px] font-mono">
                <div className="bg-slate-900/90 p-2 rounded-lg">
                  <span className="text-slate-400 block text-[10px]">Win Rate</span>
                  <span className="font-bold text-emerald-400">{strat.winRate}%</span>
                </div>
                <div className="bg-slate-900/90 p-2 rounded-lg">
                  <span className="text-slate-400 block text-[10px]">Estimated APY</span>
                  <span className="font-bold text-cyan-300">+{strat.apy}%</span>
                </div>
                <div className="bg-slate-900/90 p-2 rounded-lg">
                  <span className="text-slate-400 block text-[10px]">Total Trades</span>
                  <span className="font-bold text-white">{strat.tradesCount}</span>
                </div>
                <div className="bg-slate-900/90 p-2 rounded-lg">
                  <span className="text-slate-400 block text-[10px]">Profit Factor</span>
                  <span className="font-bold text-amber-300">{strat.profitFactor}x</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Strategy Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121926] border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>Build New Strategy</span>
              </div>
              <button
                onClick={() => setShowNewModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Strategy Name</label>
                <input
                  type="text"
                  value={newStratName}
                  onChange={(e) => setNewStratName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Trading Asset</label>
                  <select
                    value={newPair}
                    onChange={(e) => setNewPair(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-cyan-500"
                  >
                    <option value="BTC/USDT">BTC/USDT</option>
                    <option value="ETH/USDT">ETH/USDT</option>
                    <option value="SOL/USDT">SOL/USDT</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Trigger Signal</label>
                  <select
                    value={newIndicator}
                    onChange={(e) => setNewIndicator(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-cyan-500"
                  >
                    <option value="RSI Oversold (< 30) + EMA 20 Reclaim">RSI Oversold & Reclaim</option>
                    <option value="EMA 20 / 50 Golden Cross">EMA 20/50 Golden Cross</option>
                    <option value="Bollinger Band Squeeze Breakout">BB Squeeze Breakout</option>
                    <option value="CVD Volume Divergence">CVD Divergence</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1 font-sans">Take Profit %</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newTp}
                    onChange={(e) => setNewTp(parseFloat(e.target.value) || 2.0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-emerald-400 font-bold focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1 font-sans">Stop Loss %</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newSl}
                    onChange={(e) => setNewSl(parseFloat(e.target.value) || 1.0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-rose-400 font-bold focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Instant backtest simulator */}
              {backtestResult && (
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-cyan-300">180-Day Simulation Result</span>
                    <span className="text-emerald-400">Passed</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[10px]">
                    <div>Win: <strong className="text-white">{backtestResult.winRate}%</strong></div>
                    <div>APY: <strong className="text-cyan-400">+{backtestResult.apy}%</strong></div>
                    <div>PF: <strong className="text-amber-400">{backtestResult.profitFactor}x</strong></div>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={handleRunBacktest}
                disabled={backtesting}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold flex items-center gap-1.5 transition-colors"
              >
                {backtesting ? (
                  <>
                    <div className="w-3 h-3 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                    Simulating...
                  </>
                ) : (
                  'Run Backtest'
                )}
              </button>

              <button
                type="button"
                onClick={handleSaveStrategy}
                className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors shadow-md"
              >
                Save & Deploy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
