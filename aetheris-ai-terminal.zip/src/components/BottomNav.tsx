import React from 'react';
import { Compass, BarChart2, Sparkles, Cpu, User } from 'lucide-react';

export type TabType = 'radar' | 'analyze' | 'copilot' | 'automate' | 'profile';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onChangeTab }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0b0f17]/95 backdrop-blur-lg border-t border-slate-800/80 px-4 py-2 select-none">
      <div className="max-w-md mx-auto flex items-center justify-between relative">
        {/* Radar Tab */}
        <button
          id="nav-radar-btn"
          onClick={() => onChangeTab('radar')}
          className={`flex flex-col items-center gap-1 transition-all flex-1 py-1 ${
            activeTab === 'radar'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <Compass className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Radar</span>
        </button>

        {/* Analyze Tab */}
        <button
          id="nav-analyze-btn"
          onClick={() => onChangeTab('analyze')}
          className={`flex flex-col items-center gap-1 transition-all flex-1 py-1 ${
            activeTab === 'analyze'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <BarChart2 className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Analyze</span>
        </button>

        {/* Center Copilot Button matching Glowing Cyan style */}
        <button
          id="nav-copilot-center-btn"
          onClick={() => onChangeTab('copilot')}
          className="relative -top-2 flex flex-col items-center group mx-1"
          title="AI Copilot & Community"
        >
          <div
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg ${
              activeTab === 'copilot'
                ? 'bg-gradient-to-tr from-cyan-400 to-blue-500 text-slate-950 shadow-[0_0_20px_rgba(34,211,238,0.5)] scale-105'
                : 'bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700/80'
            }`}
          >
            <Sparkles className="w-5 h-5" />
          </div>
          <span
            className={`text-[9px] font-semibold mt-0.5 tracking-tight ${
              activeTab === 'copilot' ? 'text-cyan-400' : 'text-slate-500'
            }`}
          >
            Copilot
          </span>
        </button>

        {/* Automate Tab */}
        <button
          id="nav-automate-btn"
          onClick={() => onChangeTab('automate')}
          className={`flex flex-col items-center gap-1 transition-all flex-1 py-1 ${
            activeTab === 'automate'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <Cpu className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Automate</span>
        </button>

        {/* Account Tab */}
        <button
          id="nav-account-btn"
          onClick={() => onChangeTab('profile')}
          className={`flex flex-col items-center gap-1 transition-all flex-1 py-1 ${
            activeTab === 'profile'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Account</span>
        </button>
      </div>
    </nav>
  );
};
