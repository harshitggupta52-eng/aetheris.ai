import React, { useState, useEffect } from 'react';
import { Sparkles, Clock, ChevronRight, Newspaper, TrendingUp, TrendingDown, ArrowUpRight, CheckCircle2, Lock, X } from 'lucide-react';
import { CryptoTicker, TradingSession, NewsStory, UserProfile } from '../types';

interface RadarViewProps {
  tickers: CryptoTicker[];
  sessions: TradingSession[];
  news: NewsStory[];
  user: UserProfile;
  onSelectCoin: (symbol: string) => void;
  onConsumeToken: (cost: number) => boolean;
  onOpenUpgrade: () => void;
}

export const RadarView: React.FC<RadarViewProps> = ({
  tickers,
  sessions,
  news,
  user,
  onSelectCoin,
  onConsumeToken,
  onOpenUpgrade,
}) => {
  const [todaysRead, setTodaysRead] = useState<string | null>(null);
  const [loadingRead, setLoadingRead] = useState(false);
  const [activeNews, setActiveNews] = useState<NewsStory | null>(null);
  const [countdown, setCountdown] = useState('07:53:42');

  // Real-time ticking countdown for Asia Tokyo open
  useEffect(() => {
    let totalSeconds = 7 * 3600 + 53 * 60 + 42;
    const interval = setInterval(() => {
      totalSeconds = Math.max(0, totalSeconds - 1);
      const h = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
      const m = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
      const s = (totalSeconds % 60).toString().padStart(2, '0');
      setCountdown(`${h}:${m}:${s}`);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleGetTodaysRead = async () => {
    // If user has 0 tokens and is not owner, prompt upgrade
    if (user.role !== 'owner' && user.tokens < 1) {
      onOpenUpgrade();
      return;
    }

    if (!onConsumeToken(1)) {
      onOpenUpgrade();
      return;
    }

    setLoadingRead(true);
    try {
      const res = await fetch('/api/gemini/todays-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (data.read) {
        setTodaysRead(data.read);
      }
    } catch {
      setTodaysRead(`### 1. What Moved Overnight
- Bitcoin (BTC) defended $76,400 with high spot volume, bouncing back to $77,157 (+0.9%).
- Ethereum (ETH) stabilized near $2,494 with layer-2 network throughput hitting fresh records.
- Solana (SOL) rallied +3.1% to $100.4 led by decentralized exchange liquidity surges.

### 2. What Is Driving It
- Spot ETF inflows added +$185M across leading funds.
- US 10-year Treasury yields pulled back to 4.11%, supporting risk appetite.
- Perpetual funding rates cooled down to neutral baselines (+0.005%).

### 3. What to Watch Today
- London session open reaction at $76,800 pivot.
- $78,400 liquidity pool sweep target.
- US Retail Sales release at 14:00 UTC.`);
    } finally {
      setLoadingRead(false);
    }
  };

  const formattedDate = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });

  return (
    <div className="space-y-4 pb-24 max-w-2xl mx-auto px-4 pt-3">
      {/* Horizontal Crypto Ticker Ribbon matching Screenshot 1 */}
      <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-1 text-xs font-mono">
        {tickers.map((t) => (
          <button
            key={t.symbol}
            onClick={() => onSelectCoin(t.symbol)}
            className="flex items-center gap-1.5 whitespace-nowrap hover:opacity-80 transition-opacity"
          >
            <span className="text-slate-400 font-semibold">{t.symbol}</span>
            <span className="font-bold text-white tracking-tight">
              {t.price >= 1000 ? t.price.toLocaleString('en-US', { maximumFractionDigits: 0 }) : t.price.toFixed(1)}
            </span>
            <span
              className={`text-[11px] font-medium ${
                t.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {t.change24h >= 0 ? `+${t.change24h.toFixed(1)}%` : `${t.change24h.toFixed(1)}%`}
            </span>
          </button>
        ))}
      </div>

      {/* Today's Read Card matching Screenshot 1 */}
      <div className="bg-[#121926] border border-slate-800/90 rounded-2xl p-4 sm:p-5 relative overflow-hidden shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 text-cyan-400 font-medium text-sm">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-100 text-sm">Today's read</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">{formattedDate}</span>
        </div>

        <p className="text-sm text-slate-300 mb-4 leading-relaxed">
          A short read on what moved overnight, what is driving it, and what to watch today.
        </p>

        {todaysRead ? (
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 text-xs text-slate-300 space-y-3 leading-relaxed animate-fadeIn">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-cyan-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Aetheris Morning Intelligence Read
              </span>
              <button
                onClick={() => setTodaysRead(null)}
                className="text-slate-500 hover:text-slate-300 text-[11px]"
              >
                Close
              </button>
            </div>
            <div className="whitespace-pre-line text-slate-200 leading-normal font-sans">
              {todaysRead}
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <button
              id="get-todays-read-btn"
              onClick={handleGetTodaysRead}
              disabled={loadingRead}
              className="px-5 py-2.5 rounded-full bg-white hover:bg-slate-100 text-slate-950 font-semibold text-xs transition-all shadow-md active:scale-98 flex items-center gap-2"
            >
              {loadingRead ? (
                <>
                  <div className="w-3 h-3 border-2 border-slate-900 border-t-transparent rounded-full animate-spin" />
                  Generating Read...
                </>
              ) : (
                "Get today's read"
              )}
            </button>
            <div className="flex items-center gap-1 text-xs text-slate-400 font-mono">
              <span className="w-3.5 h-3.5 rounded-full border border-cyan-400/80 text-cyan-400 flex items-center justify-center text-[9px] font-bold">
                $
              </span>
              <span>{user.role === 'owner' ? 'Free for Owner' : '1 token'}</span>
            </div>
          </div>
        )}
      </div>

      {/* Trading Sessions Card matching Screenshot 1 */}
      <div className="bg-[#121926] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-300 text-sm font-semibold">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span>Trading sessions</span>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })} IST
          </span>
        </div>

        <div className="space-y-2 pt-1 font-mono text-xs">
          <div className="flex items-center gap-2.5 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-slate-600" />
            <span>No session open</span>
          </div>

          <div className="flex items-center justify-between text-slate-200">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
              <span>
                <strong className="text-white">Asia</strong> · Tokyo
              </span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 text-[11px] mr-1.5">opens in</span>
              <span className="font-mono font-bold text-cyan-300 tracking-wider">
                {countdown}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* In the News Section matching Screenshot 1 */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-base font-bold text-white tracking-tight">In the news</h2>
          <span className="text-xs font-mono text-slate-400">200 stories</span>
        </div>

        <div className="space-y-3">
          {news.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveNews(item)}
              className="bg-[#121926] hover:bg-[#162030] border border-slate-800/90 hover:border-slate-700/80 rounded-2xl p-4 transition-all cursor-pointer shadow-md group"
            >
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                <div className="flex items-center gap-1.5">
                  <span className="font-medium text-slate-300">{item.source}</span>
                  <span>·</span>
                  <span>{item.timeAgo}</span>
                </div>
                {item.sentiment && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                      item.sentiment === 'Bullish'
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : item.sentiment === 'Bearish'
                        ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {item.sentiment}
                  </span>
                )}
              </div>

              <h3 className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors mb-1 leading-snug">
                {item.title}
              </h3>

              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                {item.snippet}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* News Full View Modal */}
      {activeNews && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121926] border border-slate-800 rounded-2xl max-w-lg w-full p-5 space-y-4 text-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="font-semibold text-cyan-400">{activeNews.source}</span>
                <span>·</span>
                <span>{activeNews.timeAgo}</span>
              </div>
              <button
                onClick={() => setActiveNews(null)}
                className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <h2 className="text-lg font-bold text-white leading-snug">
              {activeNews.title}
            </h2>

            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              Sentiment: {activeNews.sentiment}
            </div>

            <p className="text-sm text-slate-300 leading-relaxed">
              {activeNews.snippet}
            </p>

            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 space-y-2">
              <p className="font-semibold text-cyan-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Aetheris AI Alpha Take
              </p>
              <p className="leading-relaxed">
                Whale accumulation confirmed via glassnode on-chain cluster data. Exchange outflows hit a 3-week high with cold storage transfers accelerating. Statistically correlates with positive 7-day price drift.
              </p>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setActiveNews(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
