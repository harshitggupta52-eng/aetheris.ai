import React, { useState } from 'react';
import { Sparkles, Send, Users, Compass, ChevronRight, Lock, Check, MessageSquare, Bot } from 'lucide-react';
import { CopilotMessage, UserProfile } from '../types';

interface CommunityViewProps {
  user: UserProfile;
  onConsumeToken: (cost: number) => boolean;
  onOpenUpgrade: () => void;
}

export const CommunityView: React.FC<CommunityViewProps> = ({
  user,
  onConsumeToken,
  onOpenUpgrade,
}) => {
  const [messages, setMessages] = useState<CopilotMessage[]>([
    {
      id: 'm1',
      sender: 'assistant',
      text: `Hello Virat! I'm your Aetheris AI Copilot. Ask me anything about current crypto markets, institutional order flow, technical setups, funding rates, or macro drivers.`,
      timestamp: 'Just now',
      suggestedPrompts: [
        'What is Bitcoin’s key support & resistance right now?',
        'Analyze ETH/USDT funding rates and liquidation levels',
        'Which altcoins are showing strongest relative volume?',
        'How should I position ahead of London & Tokyo open?',
      ],
    },
  ]);

  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const [followedChannels, setFollowedChannels] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'copilot' | 'channels'>('copilot');

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputVal;
    if (!query.trim()) return;

    if (user.role !== 'owner' && user.tokens < 1) {
      onOpenUpgrade();
      return;
    }

    if (!onConsumeToken(1)) {
      onOpenUpgrade();
      return;
    }

    const userMsg: CopilotMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: query }),
      });
      const data = await res.json();
      const reply = data.reply || "Analysis complete. Watching key price pivots.";

      setMessages((prev) => [
        ...prev,
        {
          id: `reply-${Date.now()}`,
          sender: 'assistant',
          text: reply,
          timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `reply-${Date.now()}`,
          sender: 'assistant',
          text: `**Aetheris AI Analysis for "${query}":**
- **Structure:** Price is testing local 15-minute value area highs with positive cumulative volume delta (CVD).
- **Key Support:** Defended strongly at $76,400 with high spot bid density.
- **Key Resistance:** Major liquidation pool located between $77,900 and $78,400.
- **Tactical Play:** Maintain a buy-the-dip bias above $76,800. Invalidation on an hourly close below $76,400.`,
          timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const channelsList = [
    {
      id: 'ch-1',
      name: 'Alpha Quant Desk',
      analyst: 'Dr. Michael Vance (Ex-Jane Street)',
      subscribers: '14.2K',
      winRate: '78%',
      recentSignal: 'LONG BTC $76,800 -> TP $78,400 (Active)',
      locked: false,
    },
    {
      id: 'ch-2',
      name: 'Whale Liquidation Radar',
      analyst: 'OnChain Intel Team',
      subscribers: '28.9K',
      winRate: '83%',
      recentSignal: '$45M Short cluster wiped at $77,200',
      locked: true,
    },
    {
      id: 'ch-3',
      name: 'DeFi & Altcoin Momentum',
      analyst: 'Sui & Solana Specialists',
      subscribers: '9.8K',
      winRate: '71%',
      recentSignal: 'SOL breakout continuation target $108',
      locked: true,
    },
  ];

  return (
    <div className="space-y-4 pb-24 max-w-2xl mx-auto px-4 pt-2">
      {/* Header section matching Screenshot 3 */}
      <div className="bg-[#121926] border border-slate-800 rounded-2xl p-4 shadow-lg">
        <h1 className="text-base font-bold text-white tracking-tight">Community</h1>
        <p className="text-xs text-slate-400 mt-0.5">Updates from the people you follow</p>

        {/* Tab switch */}
        <div className="flex gap-2 mt-3 p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('copilot')}
            className={`flex-1 py-1.5 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'copilot'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Copilot</span>
          </button>
          <button
            onClick={() => setActiveTab('channels')}
            className={`flex-1 py-1.5 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'channels'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Analyst Channels</span>
          </button>
        </div>
      </div>

      {activeTab === 'copilot' ? (
        /* Copilot Chat Screen matching Screenshot 3 item */
        <div className="bg-[#121926] border border-slate-800 rounded-2xl shadow-xl flex flex-col h-[520px] overflow-hidden">
          {/* Top Copilot Bar */}
          <div className="p-3.5 border-b border-slate-800 bg-[#162030]/60 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-300">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-white">Copilot</h2>
                <p className="text-[11px] text-slate-400">Ask anything about the markets</p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 text-cyan-400 border border-slate-700">
              Gemini 3.8 Quant
            </span>
          </div>

          {/* Messages stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs leading-relaxed">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.sender === 'assistant' && (
                  <div className="w-6 h-6 rounded-full bg-cyan-600/30 border border-cyan-500/40 flex items-center justify-center text-cyan-300 shrink-0 mt-0.5">
                    <Sparkles className="w-3 h-3" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 ${
                    m.sender === 'user'
                      ? 'bg-cyan-600 text-white rounded-br-none'
                      : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-none shadow-md'
                  }`}
                >
                  <div className="whitespace-pre-line leading-relaxed font-sans">
                    {m.text}
                  </div>
                  <span
                    className={`block text-[10px] font-mono mt-1 text-right ${
                      m.sender === 'user' ? 'text-cyan-100' : 'text-slate-400'
                    }`}
                  >
                    {m.timestamp}
                  </span>

                  {/* Suggested Prompts on initial assistant welcome message */}
                  {m.suggestedPrompts && (
                    <div className="mt-3 pt-2 border-t border-slate-800/80 space-y-1.5">
                      <p className="text-[11px] font-semibold text-cyan-300">Suggested queries:</p>
                      <div className="flex flex-col gap-1">
                        {m.suggestedPrompts.map((prompt, i) => (
                          <button
                            key={i}
                            onClick={() => handleSendMessage(prompt)}
                            className="text-left px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-[11px] transition-colors border border-slate-700/50"
                          >
                            → {prompt}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex gap-2.5 items-center text-slate-400 text-xs">
                <div className="w-6 h-6 rounded-full bg-cyan-600/30 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
                  <Sparkles className="w-3 h-3 animate-spin" />
                </div>
                <span>Aetheris Copilot is processing order book & market structure...</span>
              </div>
            )}
          </div>

          {/* Input Box */}
          <div className="p-3 border-t border-slate-800 bg-[#121926]">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                id="copilot-input-field"
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder="Ask anything about the markets (e.g. BTC resistance, funding rates)..."
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
              <button
                id="copilot-send-btn"
                type="submit"
                disabled={!inputVal.trim() || loading}
                className="w-9 h-9 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-950 flex items-center justify-center transition-colors shadow-md shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      ) : (
        /* Channels list matching Screenshot 3 text */
        <div className="space-y-3">
          <div className="bg-[#121926] border border-slate-800 rounded-2xl p-6 text-center shadow-lg">
            <p className="text-sm font-semibold text-slate-300">No channels yet</p>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Follow an influencer's referral link to unlock their VIP alpha channel and trade signals.
            </p>
          </div>

          <div className="space-y-2.5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
              Featured Quant Channels
            </h2>
            {channelsList.map((ch) => {
              const isFollowed = followedChannels.includes(ch.id);
              return (
                <div
                  key={ch.id}
                  className="bg-[#121926] border border-slate-800 rounded-xl p-3.5 flex items-center justify-between text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{ch.name}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        {ch.winRate} Win
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">{ch.analyst} · {ch.subscribers} followers</p>
                    <p className="text-[11px] font-mono text-cyan-300">{ch.recentSignal}</p>
                  </div>

                  <button
                    onClick={() => {
                      if (user.role === 'free' && ch.locked) {
                        onOpenUpgrade();
                        return;
                      }
                      if (isFollowed) {
                        setFollowedChannels((prev) => prev.filter((id) => id !== ch.id));
                      } else {
                        setFollowedChannels((prev) => [...prev, ch.id]);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-lg font-semibold text-xs transition-colors flex items-center gap-1 ${
                      isFollowed
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : user.role === 'free' && ch.locked
                        ? 'bg-slate-800 text-slate-400'
                        : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                    }`}
                  >
                    {isFollowed ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Following
                      </>
                    ) : user.role === 'free' && ch.locked ? (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        Pro Only
                      </>
                    ) : (
                      'Follow'
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
