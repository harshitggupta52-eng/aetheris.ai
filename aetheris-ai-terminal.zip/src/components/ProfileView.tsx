import React, { useState } from 'react';
import { ShieldCheck, ChevronRight, Gift, Key, Bell, Moon, Sun, Check, Sparkles, SlidersHorizontal, AlertCircle, X, Download, Copy, Terminal, FolderArchive, Github } from 'lucide-react';
import { UserProfile, UserRole } from '../types';

interface ProfileViewProps {
  user: UserProfile;
  onUpdateRole: (role: UserRole) => void;
  onOpenUpgrade: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  onUpdateRole,
  onOpenUpgrade,
  theme,
  onToggleTheme,
}) => {
  const [showExchangeModal, setShowExchangeModal] = useState(false);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [showGitModal, setShowGitModal] = useState(false);
  const [telegramHandle, setTelegramHandle] = useState('@harshit_trader');
  const [telegramSaved, setTelegramSaved] = useState(false);
  const [copiedGit, setCopiedGit] = useState(false);

  const gitSnippet = `# 1. Extract zip and navigate to project
cd aetheris-ai

# 2. Initialize Git and stage files
git init
git add .
git commit -m "Initial commit of Aetheris AI terminal"

# 3. Create main branch and link your GitHub repository
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/aetheris-ai.git

# 4. Push code to GitHub
git push -u origin main`;

  const handleCopyGitCommands = () => {
    navigator.clipboard.writeText(gitSnippet);
    setCopiedGit(true);
    setTimeout(() => setCopiedGit(false), 2500);
  };

  return (
    <div className="space-y-4 pb-28 max-w-2xl mx-auto px-4 pt-2">
      {/* Account Heading matching Screenshot 5 */}
      <div className="flex items-center gap-2 px-1">
        <h1 className="text-lg font-bold text-white tracking-tight">Account</h1>
      </div>

      {/* User Info Avatar & Email matching Screenshot 5 */}
      <div className="flex items-center gap-3.5 px-1 py-1">
        <div className="w-12 h-12 rounded-full bg-[#1e293b] border border-slate-700 flex items-center justify-center text-cyan-400 font-bold text-lg shadow-inner">
          {user.avatarLetter}
        </div>
        <div className="overflow-hidden">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-tight truncate">
              {user.name}
            </h2>
            {user.role === 'owner' && (
              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                OWNER
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 font-mono truncate">{user.email}</p>
        </div>
      </div>

      {/* Plan Card matching Screenshot 5 */}
      <div className="bg-[#121926] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white">
              {user.role === 'owner'
                ? 'Founder & Owner Plan'
                : user.role === 'pro'
                ? 'Pro Member Plan'
                : 'Free plan'}
            </h3>
            <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-1 font-mono">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>
                {user.role === 'owner'
                  ? '∞ Unlimited AI tokens (Lifetime Free)'
                  : user.role === 'pro'
                  ? '250 tokens remaining'
                  : `${user.tokens} tokens left`}
              </span>
            </div>
          </div>

          {user.role === 'owner' ? (
            <div className="px-3.5 py-1.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-semibold flex items-center gap-1.5 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Owner VIP</span>
            </div>
          ) : (
            <button
              id="upgrade-plan-btn"
              onClick={onOpenUpgrade}
              className="px-4 py-2 rounded-full bg-white hover:bg-slate-100 text-slate-950 font-semibold text-xs transition-colors shadow-md active:scale-98"
            >
              Upgrade
            </button>
          )}
        </div>

        {user.role === 'owner' && (
          <p className="text-[11px] text-slate-400 pt-1 border-t border-slate-800/80 leading-relaxed">
            As the platform owner (<code className="text-amber-300 font-mono">{user.email}</code>), you have permanent, unlimited zero-cost access to all institutional models, multi-lane chart analysis, and strategy engines.
          </p>
        )}
      </div>

      {/* Owner Mode Switcher (Role Simulator) */}
      <div className="bg-[#121926] border border-cyan-900/40 rounded-2xl p-4 shadow-lg space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Role Simulator
            </h3>
          </div>
          <span className="text-[10px] font-mono text-cyan-400">Testing Tools</span>
        </div>
        <p className="text-[11px] text-slate-400">
          Switch between Owner (Free Unlimited), Free User (Paywall / 0 Tokens), and Paid Pro to test user flows:
        </p>

        <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-xs">
          <button
            onClick={() => onUpdateRole('owner')}
            className={`p-2 rounded-xl border text-center transition-all ${
              user.role === 'owner'
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-200 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="block text-amber-400 text-sm mb-0.5">👑</span>
            <span className="text-[10px] font-sans block">Owner</span>
            <span className="text-[9px] text-amber-400/80">100% Free</span>
          </button>

          <button
            onClick={() => onUpdateRole('free')}
            className={`p-2 rounded-xl border text-center transition-all ${
              user.role === 'free'
                ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="block text-slate-400 text-sm mb-0.5">👤</span>
            <span className="text-[10px] font-sans block">Free User</span>
            <span className="text-[9px] text-rose-400/90">0 Tokens</span>
          </button>

          <button
            onClick={() => onUpdateRole('pro')}
            className={`p-2 rounded-xl border text-center transition-all ${
              user.role === 'pro'
                ? 'bg-blue-500/20 border-blue-500/50 text-blue-200 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="block text-cyan-400 text-sm mb-0.5">⚡</span>
            <span className="text-[10px] font-sans block">Paid Pro</span>
            <span className="text-[9px] text-cyan-400">$29/mo</span>
          </button>
        </div>
      </div>

      {/* GitHub Repository Export & ZIP Download Card */}
      <div className="bg-[#121926] border border-cyan-500/30 rounded-2xl p-4 sm:p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FolderArchive className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white tracking-tight">
              Export Project for GitHub
            </h3>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-[10px] font-mono text-cyan-300 font-semibold">
            ZIP Ready
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Download the full production-ready code archive with all components, Express backend, and configuration files ready to paste into GitHub.
        </p>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
          <a
            id="download-zip-link"
            href="/aetheris-ai.zip"
            download="aetheris-ai-terminal.zip"
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-md transition-all active:scale-98"
          >
            <Download className="w-4 h-4" />
            <span>Download Project ZIP</span>
          </a>

          <button
            id="open-git-commands-btn"
            onClick={() => setShowGitModal(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-white font-medium text-xs transition-colors"
          >
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>GitHub Push Guide</span>
          </button>
        </div>

        <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
          <span>Includes: React 19, TypeScript, Express, Tailwind, README.md</span>
          <span className="font-mono text-cyan-400">~43 KB</span>
        </div>
      </div>

      {/* Free Pro plan Referral notice Card matching Screenshot 5 */}
      <div className="bg-[#121926] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg space-y-2">
        <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold">
          <Gift className="w-4 h-4 text-cyan-400" />
          <span>Free Pro plan</span>
        </div>
        <div className="flex items-start gap-2 text-xs text-slate-400 leading-relaxed">
          <AlertCircle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
          <p>
            We couldn't verify that Delta ID as a referred account. This offer is now closed for your account.
          </p>
        </div>
      </div>

      {/* Settings Navigation List matching Screenshot 5 */}
      <div className="bg-[#121926] border border-slate-800 rounded-2xl overflow-hidden shadow-lg divide-y divide-slate-800/80 text-xs">
        {/* Exchanges row */}
        <button
          onClick={() => setShowExchangeModal(true)}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#162030] transition-colors group"
        >
          <div>
            <h4 className="font-semibold text-white text-sm">Exchanges</h4>
            <p className="text-xs text-slate-400">Where your trades execute</p>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 group-hover:text-cyan-400 transition-all" />
        </button>

        {/* Alerts and notifications row */}
        <button
          onClick={() => setShowAlertModal(true)}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#162030] transition-colors group"
        >
          <div>
            <h4 className="font-semibold text-white text-sm">Alerts and notifications</h4>
            <p className="text-xs text-slate-400">Telegram signals</p>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 group-hover:text-cyan-400 transition-all" />
        </button>

        {/* Appearance row */}
        <div className="p-4 flex items-center justify-between">
          <div>
            <h4 className="font-semibold text-white text-sm">Appearance</h4>
            <p className="text-xs text-slate-400">Light or dark on this device</p>
          </div>
          <button
            onClick={onToggleTheme}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            {theme === 'dark' ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
            <span>{theme === 'dark' ? 'Dark' : 'Light'}</span>
          </button>
        </div>
      </div>

      {/* Exchanges Modal */}
      {showExchangeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121926] border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <Key className="w-4 h-4 text-cyan-400" />
                <span>Connected Exchanges</span>
              </div>
              <button
                onClick={() => setShowExchangeModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-400">
              Connect your read-only API keys or sub-account execution credentials:
            </p>

            <div className="space-y-2">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-white block">Binance Futures</span>
                  <span className="text-[10px] text-emerald-400">Connected (Read & Execute)</span>
                </div>
                <span className="text-[10px] text-slate-500 font-mono">API ***8471</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-white block">Bybit Derivatives</span>
                  <span className="text-[10px] text-slate-500">Not configured</span>
                </div>
                <button className="px-2.5 py-1 rounded bg-slate-800 text-cyan-400 text-[11px] font-semibold">
                  Connect
                </button>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-white block">Coinbase Pro</span>
                  <span className="text-[10px] text-slate-500">Not configured</span>
                </div>
                <button className="px-2.5 py-1 rounded bg-slate-800 text-cyan-400 text-[11px] font-semibold">
                  Connect
                </button>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowExchangeModal(false)}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Alerts Modal */}
      {showAlertModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121926] border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <Bell className="w-4 h-4 text-cyan-400" />
                <span>Telegram Trade Alerts</span>
              </div>
              <button
                onClick={() => setShowAlertModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-400">
              Receive instant alerts for 4-lane AI chart setups and bot executions directly to your Telegram:
            </p>

            <div className="space-y-2">
              <label className="block text-slate-300 font-semibold">Telegram Username</label>
              <input
                type="text"
                value={telegramHandle}
                onChange={(e) => {
                  setTelegramHandle(e.target.value);
                  setTelegramSaved(false);
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>

            {telegramSaved && (
              <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Telegram bot connected! Test signal dispatched.</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setTelegramSaved(true)}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold"
              >
                Save & Connect
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GitHub Push Guide Modal */}
      {showGitModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121926] border border-cyan-500/40 rounded-2xl max-w-lg w-full p-5 space-y-4 text-xs shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <Github className="w-4 h-4 text-cyan-400" />
                <span>GitHub Push & Paste Instructions</span>
              </div>
              <button
                onClick={() => setShowGitModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-300 leading-relaxed">
              Follow these simple terminal commands to initialize git and push the extracted archive directly to your new GitHub repository:
            </p>

            <div className="relative group bg-[#090d14] rounded-xl border border-slate-800 p-3 font-mono text-[11px] text-cyan-300 overflow-x-auto">
              <pre className="whitespace-pre">{gitSnippet}</pre>
              <button
                onClick={handleCopyGitCommands}
                className="absolute top-2.5 right-2.5 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[10px] font-sans transition-all"
              >
                {copiedGit ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Commands</span>
                  </>
                )}
              </button>
            </div>

            <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-1.5 text-[11px] text-slate-400">
              <p className="text-slate-200 font-semibold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Also Available in AI Studio Menu:
              </p>
              <p>
                You can also export directly to GitHub or download a ZIP via the top Settings menu in Google AI Studio.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <a
                href="/aetheris-ai.zip"
                download="aetheris-ai-terminal.zip"
                className="flex items-center gap-1.5 text-cyan-400 hover:underline font-medium"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Direct ZIP Download</span>
              </a>

              <button
                onClick={() => setShowGitModal(false)}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
