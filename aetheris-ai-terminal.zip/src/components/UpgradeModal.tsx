import React, { useState } from 'react';
import { X, Check, Sparkles, Shield, Zap, ArrowRight } from 'lucide-react';
import { UserRole } from '../types';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPlan: (role: UserRole, tokensToAdd: number) => void;
  currentRole: UserRole;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  isOpen,
  onClose,
  onSelectPlan,
  currentRole,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-[#121926] border border-slate-800 rounded-3xl max-w-xl w-full p-5 sm:p-6 space-y-5 shadow-2xl relative animate-fadeIn my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center space-y-1.5 pt-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Institutional Quantitative AI</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Upgrade to Aetheris Pro
          </h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Unlock four-lane AI chart analysis, automated strategy deployment, and unlimited market copilot queries.
          </p>

          {/* Billing Switch */}
          <div className="inline-flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs font-medium mt-2">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                billingCycle === 'monthly'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1 ${
                billingCycle === 'yearly'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Yearly</span>
              <span className="text-[10px] bg-emerald-400 text-slate-950 px-1 rounded font-extrabold">
                Save 25%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
          {/* Pro Trader Card */}
          <div className="bg-gradient-to-b from-slate-900 to-[#162030] border-2 border-cyan-500/60 rounded-2xl p-4 space-y-3.5 relative shadow-lg">
            <div className="absolute -top-2.5 right-4 px-2 py-0.5 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-extrabold tracking-wider uppercase shadow-sm">
              Most Popular
            </div>

            <div>
              <h3 className="font-bold text-white text-sm">Pro Trader</h3>
              <p className="text-[11px] text-slate-400">For active crypto traders</p>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-white">
                  {billingCycle === 'monthly' ? '$29' : '$21'}
                </span>
                <span className="text-slate-400 text-xs font-mono">/ month</span>
              </div>
            </div>

            <ul className="space-y-2 text-slate-300">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span><strong>250 AI Tokens</strong> refreshed monthly</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>4-Lane AI Chart Analysis ("The One Call")</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Unlock all Top Performer Trading Bots</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Telegram signals & liquidation alerts</span>
              </li>
            </ul>

            <button
              onClick={() => {
                onSelectPlan('pro', 250);
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Activate Pro Plan</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Institutional Elite Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3.5 shadow-md">
            <div>
              <h3 className="font-bold text-white text-sm">Institutional Elite</h3>
              <p className="text-[11px] text-slate-400">For quants & high-volume funds</p>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-white">
                  {billingCycle === 'monthly' ? '$79' : '$59'}
                </span>
                <span className="text-slate-400 text-xs font-mono">/ month</span>
              </div>
            </div>

            <ul className="space-y-2 text-slate-300">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span><strong>Unlimited AI Tokens</strong></span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Direct Exchange API auto-execution</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Custom Python & PineScript Backtesting</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Private Alpha Quant Channel Access</span>
              </li>
            </ul>

            <button
              onClick={() => {
                onSelectPlan('pro', 1000);
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
            >
              Activate Elite Plan
            </button>
          </div>
        </div>

        {/* Quick Token Refill Packs */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3.5 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-200">Or buy standalone token refill:</span>
            <span className="text-[10px] text-slate-400">Tokens never expire</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                onSelectPlan(currentRole, 50);
                onClose();
              }}
              className="flex-1 p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/60 flex items-center justify-between"
            >
              <span className="font-mono font-bold">+50 Tokens</span>
              <span className="text-cyan-400 font-bold">$4.99</span>
            </button>
            <button
              onClick={() => {
                onSelectPlan(currentRole, 150);
                onClose();
              }}
              className="flex-1 p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/60 flex items-center justify-between"
            >
              <span className="font-mono font-bold">+150 Tokens</span>
              <span className="text-cyan-400 font-bold">$9.99</span>
            </button>
          </div>
        </div>

        {/* Note on Owner Access */}
        <div className="text-center text-[11px] text-slate-500 pt-1">
          Platform Owner (<code className="text-cyan-400 font-mono">harshitggupta52@gmail.com</code>) receives 100% Free Lifetime VIP with no payment required.
        </div>
      </div>
    </div>
  );
};
