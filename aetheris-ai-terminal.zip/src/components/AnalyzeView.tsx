import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, ChevronDown, ChevronUp, Bell, Layers, ChevronRight, RefreshCw, CheckCircle2, TrendingUp, TrendingDown, Target, ShieldAlert, ArrowUpRight } from 'lucide-react';
import { Candle, CryptoTicker, AiChartAnalysis, UserProfile } from '../types';
import { generateCandlesForPair } from '../data/mockData';

interface AnalyzeViewProps {
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  tickers: CryptoTicker[];
  user: UserProfile;
  onConsumeToken: (cost: number) => boolean;
  onOpenUpgrade: () => void;
}

export const AnalyzeView: React.FC<AnalyzeViewProps> = ({
  selectedSymbol,
  onSelectSymbol,
  tickers,
  user,
  onConsumeToken,
  onOpenUpgrade,
}) => {
  const [timeframe, setTimeframe] = useState<'1M' | '5M' | '15M' | '1H' | '4H' | '1D'>('15M');
  const [candles, setCandles] = useState<Candle[]>([]);
  const [hoverCandle, setHoverCandle] = useState<Candle | null>(null);
  const [overlayEma, setOverlayEma] = useState(true);
  const [showPairMenu, setShowPairMenu] = useState(false);
  const [showTfMenu, setShowTfMenu] = useState(false);
  const [showOverlayMenu, setShowOverlayMenu] = useState(false);
  const [aiDrawerOpen, setAiDrawerOpen] = useState(true);
  const [analysis, setAnalysis] = useState<AiChartAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [alertSet, setAlertSet] = useState(false);

  const currentTicker = tickers.find((t) => t.symbol === selectedSymbol) || tickers[0];

  // Refresh candle dataset when symbol or timeframe changes
  useEffect(() => {
    const data = generateCandlesForPair(currentTicker.pair);
    setCandles(data);
    setHoverCandle(data[data.length - 1]);
    fetchAnalysis(currentTicker.pair, currentTicker.price, currentTicker.change24h);
  }, [selectedSymbol, timeframe]);

  // Fetch AI Analysis matching "Four lanes read this chart and give one call"
  const fetchAnalysis = async (pair: string, price: number, change: number) => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/gemini/chart-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pair, price, change24h: `${change}%`, timeframe }),
      });
      const data = await res.json();
      if (data.lane1 && data.theCall) {
        setAnalysis(data);
      }
    } catch {
      // Fallback
      setAnalysis({
        lane1: {
          title: 'Trend & Market Structure',
          status: 'Bullish Reclaiming Structure',
          details: `Price bounced firmly off the 15M value area low ($${(price * 0.992).toFixed(1)}) and printed strong engulfing candles through resistance. Higher lows confirmed.`,
        },
        lane2: {
          title: 'Momentum & Order Flow',
          status: 'Positive CVD Divergence',
          details: 'RSI trending at 58.6 with strong spot order book absorption. Net sell market orders failed to push price lower.',
        },
        lane3: {
          title: 'Volatility & Liquidity Pools',
          status: 'Short Liquidity Sweep Target',
          details: `Upper Bollinger Band expanding. Clustered buy-stop liquidations stacked between $${(price * 1.012).toFixed(0)} and $${(price * 1.018).toFixed(0)}.`,
        },
        lane4: {
          title: 'Derivatives & Sentiment',
          status: 'Clean Leverage Profile',
          details: 'Funding rate remains neutral at +0.005%. Open interest up 3.2% alongside spot price growth, validating organic demand.',
        },
        theCall: {
          bias: 'LONG',
          headline: `Breakout Expansion to $${(price * 1.016).toFixed(0)}`,
          summary: 'All four lanes converge on upward continuation. Look for pullbacks into the local consolidation band to initiate positions.',
          entryZone: `$${(price * 0.998).toFixed(1)} – $${(price * 1.002).toFixed(1)}`,
          target: `$${(price * 1.016).toFixed(1)}`,
          stopLoss: `$${(price * 0.993).toFixed(1)}`,
          riskReward: '2.85 : 1',
          confidence: 88,
        },
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleRunNewAiScan = () => {
    if (user.role !== 'owner' && user.tokens < 1) {
      onOpenUpgrade();
      return;
    }
    if (!onConsumeToken(1)) {
      onOpenUpgrade();
      return;
    }
    fetchAnalysis(currentTicker.pair, currentTicker.price, currentTicker.change24h);
  };

  // Math for SVG Candlestick Chart
  const minPrice = Math.min(...candles.map((c) => c.low)) * 0.998;
  const maxPrice = Math.max(...candles.map((c) => c.high)) * 1.002;
  const priceRange = maxPrice - minPrice || 1;

  const chartWidth = 500;
  const chartHeight = 320;
  const candleSpacing = chartWidth / Math.max(candles.length, 1);
  const candleBodyWidth = Math.max(candleSpacing * 0.6, 3);

  const getY = (price: number) => {
    return chartHeight - ((price - minPrice) / priceRange) * chartHeight;
  };

  // Price steps for vertical scale matching screenshot
  const scaleSteps = 6;
  const priceTicks = Array.from({ length: scaleSteps }, (_, i) => {
    return maxPrice - (i / (scaleSteps - 1)) * priceRange;
  });

  const latestPrice = currentTicker.price;
  const currentY = getY(latestPrice);

  return (
    <div className="space-y-3 pb-24 max-w-2xl mx-auto px-3 sm:px-4 pt-2">
      {/* "Explore market data >" Banner matching Screenshot 2 */}
      <button
        id="explore-market-data-btn"
        onClick={() => setShowPairMenu(true)}
        className="w-full bg-[#121926] hover:bg-[#162030] border border-slate-800 rounded-xl p-3 flex items-center justify-between text-left text-xs font-semibold text-slate-200 transition-colors shadow-sm group"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Layers className="w-3.5 h-3.5" />
          </div>
          <span className="text-sm font-bold text-white tracking-tight">
            Explore market data
          </span>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
      </button>

      {/* Selectors Bar: BTC v, 15M v, Overlays v, Alert bell v matching Screenshot 2 */}
      <div className="flex items-center justify-between gap-1.5 font-mono text-xs">
        <div className="flex items-center gap-1.5">
          {/* Pair Selector Button */}
          <div className="relative">
            <button
              id="pair-selector-btn"
              onClick={() => setShowPairMenu(!showPairMenu)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#121926] hover:bg-slate-800 border border-slate-800 text-slate-200 font-bold tracking-tight text-xs"
            >
              <span>{currentTicker.symbol}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {showPairMenu && (
              <div className="absolute left-0 mt-1.5 w-44 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-1.5 z-40">
                {tickers.map((t) => (
                  <button
                    key={t.symbol}
                    onClick={() => {
                      onSelectSymbol(t.symbol);
                      setShowPairMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs ${
                      selectedSymbol === t.symbol
                        ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                        : 'hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <span>{t.pair}</span>
                    <span
                      className={`text-[10px] ${
                        t.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {t.change24h >= 0 ? `+${t.change24h}%` : `${t.change24h}%`}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Timeframe Selector Button */}
          <div className="relative">
            <button
              id="timeframe-selector-btn"
              onClick={() => setShowTfMenu(!showTfMenu)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#121926] hover:bg-slate-800 border border-slate-800 text-slate-200 font-bold text-xs"
            >
              <span>{timeframe}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {showTfMenu && (
              <div className="absolute left-0 mt-1.5 w-28 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-1.5 z-40">
                {(['1M', '5M', '15M', '1H', '4H', '1D'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => {
                      setTimeframe(tf);
                      setShowTfMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono ${
                      timeframe === tf
                        ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                        : 'hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Overlays Selector Button */}
          <div className="relative">
            <button
              id="overlays-selector-btn"
              onClick={() => setShowOverlayMenu(!showOverlayMenu)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#121926] hover:bg-slate-800 border border-slate-800 text-slate-200 font-medium text-xs"
            >
              <span>Overlays</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {showOverlayMenu && (
              <div className="absolute left-0 mt-1.5 w-44 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-40 space-y-1">
                <button
                  onClick={() => setOverlayEma(!overlayEma)}
                  className="w-full flex items-center justify-between text-xs px-2 py-1.5 rounded-lg hover:bg-slate-800 text-slate-200"
                >
                  <span>EMA 20 / 50</span>
                  <span className={`text-[10px] font-bold ${overlayEma ? 'text-cyan-400' : 'text-slate-500'}`}>
                    {overlayEma ? 'ON' : 'OFF'}
                  </span>
                </button>
                <div className="px-2 py-1 text-[10px] text-slate-500">
                  TradingView standard indicators
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Alert Bell Button */}
        <button
          id="alert-bell-btn"
          onClick={() => setAlertSet(!alertSet)}
          className={`flex items-center gap-1 px-2.5 py-1.5 rounded-full border text-xs transition-colors ${
            alertSet
              ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
              : 'bg-[#121926] hover:bg-slate-800 border-slate-800 text-slate-400'
          }`}
          title="Toggle Price Alert"
        >
          <Bell className={`w-3.5 h-3.5 ${alertSet ? 'text-cyan-400 fill-cyan-400' : ''}`} />
          <ChevronDown className="w-3 h-3 text-slate-500" />
        </button>
      </div>

      {/* Candlestick Interactive Chart Area matching Screenshot 2 */}
      <div className="relative bg-[#0d131f] border border-slate-800/90 rounded-2xl p-2 sm:p-3 overflow-hidden shadow-2xl select-none">
        {/* Hover info bar */}
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-2 py-1 border-b border-slate-800/60 mb-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">{currentTicker.pair}</span>
            <span>O: <strong className="text-slate-200">{hoverCandle?.open.toFixed(1)}</strong></span>
            <span>H: <strong className="text-slate-200">{hoverCandle?.high.toFixed(1)}</strong></span>
            <span>L: <strong className="text-slate-200">{hoverCandle?.low.toFixed(1)}</strong></span>
            <span>C: <strong className={hoverCandle && hoverCandle.close >= hoverCandle.open ? 'text-emerald-400' : 'text-rose-400'}>{hoverCandle?.close.toFixed(1)}</strong></span>
          </div>
          <span className="text-[10px] text-slate-500">{hoverCandle?.time}</span>
        </div>

        {/* Main Chart SVG */}
        <div className="relative h-[320px] w-full flex">
          {/* Chart drawing canvas/svg */}
          <div className="flex-1 relative h-full">
            <svg
              className="w-full h-full overflow-visible"
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              preserveAspectRatio="none"
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const ratio = Math.max(0, Math.min(1, x / rect.width));
                const index = Math.min(candles.length - 1, Math.floor(ratio * candles.length));
                if (candles[index]) setHoverCandle(candles[index]);
              }}
              onMouseLeave={() => setHoverCandle(candles[candles.length - 1])}
            >
              <defs>
                <linearGradient id="chartGrid" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#1e293b" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#0f172a" stopOpacity="0.1" />
                </linearGradient>
              </defs>

              {/* Horizontal Grid lines */}
              {priceTicks.map((price, idx) => {
                const y = getY(price);
                return (
                  <line
                    key={idx}
                    x1="0"
                    y1={y}
                    x2={chartWidth}
                    y2={y}
                    stroke="#1e293b"
                    strokeWidth="0.8"
                    strokeDasharray="3 3"
                  />
                );
              })}

              {/* Vertical time division grid lines (06:00, 12:00, 16:00) */}
              <line x1={chartWidth * 0.2} y1="0" x2={chartWidth * 0.2} y2={chartHeight} stroke="#1e293b" strokeWidth="0.8" strokeDasharray="3 3" />
              <line x1={chartWidth * 0.55} y1="0" x2={chartWidth * 0.55} y2={chartHeight} stroke="#1e293b" strokeWidth="0.8" strokeDasharray="3 3" />
              <line x1={chartWidth * 0.85} y1="0" x2={chartWidth * 0.85} y2={chartHeight} stroke="#1e293b" strokeWidth="0.8" strokeDasharray="3 3" />

              {/* EMA 20 Overlay Line */}
              {overlayEma && candles.length > 5 && (
                <path
                  d={candles
                    .map((c, i) => {
                      const x = i * candleSpacing + candleSpacing / 2;
                      const emaVal = c.close * 0.999 + (Math.sin(i / 3) * 30);
                      const y = getY(emaVal);
                      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                    })
                    .join(' ')}
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="1.2"
                  strokeOpacity="0.8"
                />
              )}

              {/* Candlestick Wicks & Bodies */}
              {candles.map((candle, idx) => {
                const xCenter = idx * candleSpacing + candleSpacing / 2;
                const yHigh = getY(candle.high);
                const yLow = getY(candle.low);
                const yOpen = getY(candle.open);
                const yClose = getY(candle.close);

                const isGreen = candle.close >= candle.open;
                const candleColor = isGreen ? '#10b981' : '#f43f5e'; // Green vs Red matching screenshot

                const bodyTop = Math.min(yOpen, yClose);
                const bodyHeight = Math.max(Math.abs(yClose - yOpen), 1.5);

                return (
                  <g key={candle.timestamp} className="cursor-crosshair">
                    {/* Wick */}
                    <line
                      x1={xCenter}
                      y1={yHigh}
                      x2={xCenter}
                      y2={yLow}
                      stroke={candleColor}
                      strokeWidth="1.2"
                    />
                    {/* Body */}
                    <rect
                      x={xCenter - candleBodyWidth / 2}
                      y={bodyTop}
                      width={candleBodyWidth}
                      height={bodyHeight}
                      fill={candleColor}
                      rx="0.5"
                    />
                  </g>
                );
              })}

              {/* Live Price Horizontal Dashed Line across the chart */}
              <line
                x1="0"
                y1={currentY}
                x2={chartWidth}
                y2={currentY}
                stroke="#10b981"
                strokeWidth="1.2"
                strokeDasharray="2 2"
              />
            </svg>

            {/* TradingView Icon watermark at bottom-left matching screenshot */}
            <div className="absolute bottom-2 left-2 flex items-center gap-1 opacity-70 pointer-events-none">
              <div className="flex items-center">
                <span className="font-extrabold text-white text-base tracking-tighter">TV</span>
              </div>
            </div>

            {/* Time Axis (06:00, 12:00, 16:00) */}
            <div className="absolute -bottom-5 left-0 right-0 flex justify-between px-6 text-[10px] font-mono text-slate-400 pointer-events-none">
              <span>06:00</span>
              <span>12:00</span>
              <span>16:00</span>
            </div>
          </div>

          {/* Right vertical price axis with live badge matching screenshot */}
          <div className="w-16 h-full relative border-l border-slate-800/80 font-mono text-[10px] text-slate-400 select-none pl-1.5">
            {priceTicks.map((price, idx) => {
              const y = getY(price);
              return (
                <div
                  key={idx}
                  className="absolute -translate-y-1/2"
                  style={{ top: `${(y / chartHeight) * 100}%` }}
                >
                  {price >= 1000 ? price.toFixed(0) : price.toFixed(1)}
                </div>
              );
            })}

            {/* Live Green Price Badge matching Screenshot 2 (e.g. 77157.01) */}
            <div
              className="absolute -translate-y-1/2 -left-1 z-20"
              style={{ top: `${(currentY / chartHeight) * 100}%` }}
            >
              <div className="bg-[#10b981] text-slate-950 font-bold px-1.5 py-0.5 rounded text-[11px] tracking-tight shadow-md">
                {latestPrice >= 1000 ? latestPrice.toFixed(2) : latestPrice.toFixed(2)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Analysis Drawer matching Screenshot 2 ("Four lanes read this chart and give one call") */}
      <div className="bg-[#121926] border border-slate-800/90 rounded-2xl overflow-hidden shadow-xl">
        {/* Drawer Header button with Sparkle and Chevron */}
        <button
          id="toggle-ai-analysis-drawer"
          onClick={() => setAiDrawerOpen(!aiDrawerOpen)}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#162030] transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">AI analysis</h3>
              <p className="text-xs text-slate-400">
                Four lanes read this chart and give one call
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isAnalyzing && (
              <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
            )}
            {aiDrawerOpen ? (
              <ChevronUp className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            )}
          </div>
        </button>

        {/* Expandable Body */}
        {aiDrawerOpen && analysis && (
          <div className="p-4 pt-1 space-y-4 border-t border-slate-800/70 text-xs">
            {/* The One Call Banner */}
            <div className="bg-gradient-to-r from-cyan-950/40 via-slate-900 to-blue-950/40 border border-cyan-500/30 rounded-xl p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-md text-[11px] font-extrabold uppercase font-mono tracking-wider ${
                      analysis.theCall.bias === 'LONG'
                        ? 'bg-emerald-500 text-slate-950'
                        : analysis.theCall.bias === 'SHORT'
                        ? 'bg-rose-500 text-white'
                        : 'bg-amber-500 text-slate-950'
                    }`}
                  >
                    {analysis.theCall.bias} CALL
                  </span>
                  <span className="font-bold text-white text-xs">
                    {analysis.theCall.headline}
                  </span>
                </div>
                <span className="text-[11px] font-mono text-cyan-300 font-semibold">
                  {analysis.theCall.confidence}% Confidence
                </span>
              </div>

              <p className="text-slate-300 text-xs leading-relaxed">
                {analysis.theCall.summary}
              </p>

              {/* Execution targets */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[11px]">
                <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Entry Zone</span>
                  <span className="font-semibold text-white">{analysis.theCall.entryZone}</span>
                </div>
                <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Take Profit</span>
                  <span className="font-semibold text-emerald-400">{analysis.theCall.target}</span>
                </div>
                <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Invalidation (SL)</span>
                  <span className="font-semibold text-rose-400">{analysis.theCall.stopLoss}</span>
                </div>
                <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Risk / Reward</span>
                  <span className="font-semibold text-cyan-300">{analysis.theCall.riskReward}</span>
                </div>
              </div>
            </div>

            {/* The 4 Lanes Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Lane 1 */}
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3 space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-slate-300">Lane 1: {analysis.lane1.title}</span>
                  <span className="text-[10px] text-emerald-400 font-mono font-medium">
                    {analysis.lane1.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {analysis.lane1.details}
                </p>
              </div>

              {/* Lane 2 */}
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3 space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-slate-300">Lane 2: {analysis.lane2.title}</span>
                  <span className="text-[10px] text-cyan-400 font-mono font-medium">
                    {analysis.lane2.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {analysis.lane2.details}
                </p>
              </div>

              {/* Lane 3 */}
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3 space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-slate-300">Lane 3: {analysis.lane3.title}</span>
                  <span className="text-[10px] text-amber-400 font-mono font-medium">
                    {analysis.lane3.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {analysis.lane3.details}
                </p>
              </div>

              {/* Lane 4 */}
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3 space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-slate-300">Lane 4: {analysis.lane4.title}</span>
                  <span className="text-[10px] text-blue-400 font-mono font-medium">
                    {analysis.lane4.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {analysis.lane4.details}
                </p>
              </div>
            </div>

            {/* Trigger Re-scan button */}
            <div className="pt-1 flex items-center justify-between text-slate-400 text-xs">
              <span className="font-mono text-[11px]">
                {user.role === 'owner' ? '👑 Owner: Unlimited AI Scans' : 'Cost: 1 Token'}
              </span>
              <button
                id="rescan-chart-ai-btn"
                onClick={handleRunNewAiScan}
                disabled={isAnalyzing}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
                <span>Re-scan with AI</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
