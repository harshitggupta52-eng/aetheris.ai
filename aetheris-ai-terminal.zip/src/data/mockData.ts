import { CryptoTicker, TradingSession, NewsStory, Candle, TradingStrategy } from '../types';

export const INITIAL_TICKERS: CryptoTicker[] = [
  {
    symbol: 'BTC',
    pair: 'BTC/USDT',
    name: 'Bitcoin',
    price: 77157.01,
    change24h: -0.3,
    high24h: 77480.0,
    low24h: 76420.0,
    volume24h: '$38.4B',
  },
  {
    symbol: 'ETH',
    pair: 'ETH/USDT',
    name: 'Ethereum',
    price: 2494.2,
    change24h: -1.6,
    high24h: 2542.0,
    low24h: 2470.0,
    volume24h: '$16.2B',
  },
  {
    symbol: 'SOL',
    pair: 'SOL/USDT',
    name: 'Solana',
    price: 100.4,
    change24h: -1.5,
    high24h: 104.8,
    low24h: 98.2,
    volume24h: '$4.1B',
  },
  {
    symbol: 'BNB',
    pair: 'BNB/USDT',
    name: 'BNB Chain',
    price: 584.6,
    change24h: 0.8,
    high24h: 592.0,
    low24h: 578.0,
    volume24h: '$1.3B',
  },
  {
    symbol: 'AVAX',
    pair: 'AVAX/USDT',
    name: 'Avalanche',
    price: 31.85,
    change24h: 2.4,
    high24h: 32.9,
    low24h: 30.5,
    volume24h: '$740M',
  },
];

export const INITIAL_SESSIONS: TradingSession[] = [
  {
    id: 'asia',
    name: 'Asia',
    city: 'Tokyo',
    status: 'closed',
    openTimeUTC: '00:00',
    closeTimeUTC: '09:00',
    opensIn: '07:54:07',
  },
  {
    id: 'london',
    name: 'Europe',
    city: 'London',
    status: 'closed',
    openTimeUTC: '08:00',
    closeTimeUTC: '16:30',
    opensIn: '12:45:20',
  },
  {
    id: 'ny',
    name: 'US',
    city: 'New York',
    status: 'closed',
    openTimeUTC: '13:30',
    closeTimeUTC: '20:00',
    opensIn: '17:15:10',
  },
];

export const INITIAL_NEWS: NewsStory[] = [
  {
    id: 'news-1',
    source: 'CoinTelegraph',
    timeAgo: '23h',
    title: "Here's what happened in crypto today",
    snippet: 'Need to know what happened in crypto today? Here is the latest news on daily trends and events impacting Bitcoin and institutional accumulation patterns.',
    sentiment: 'Bullish',
    category: 'Market Wrap',
    readTime: '3 min',
  },
  {
    id: 'news-2',
    source: 'CoinDesk',
    timeAgo: '1d',
    title: 'Spot Bitcoin ETFs absorb $320M in fresh net inflows despite range consolidation',
    snippet: 'Major asset managers continue aggressive dip allocation as on-chain wallet clusters show low exchange reserves across global platforms.',
    sentiment: 'Bullish',
    category: 'Institutional',
    readTime: '4 min',
  },
  {
    id: 'news-3',
    source: 'Decrypt',
    timeAgo: '1d',
    title: 'Ethereum layer-2 gas optimization reaches critical milestone ahead of rollup update',
    snippet: 'Gas fees remain sub-cent while total value locked crosses $42 billion across top rollups, cementing Ethereum network settlements.',
    sentiment: 'Neutral',
    category: 'Technology',
    readTime: '2 min',
  },
  {
    id: 'news-4',
    source: 'Bloomberg Crypto',
    timeAgo: '2d',
    title: 'Macro volatility compression hints at impending fourth-quarter momentum breakout',
    snippet: 'Derivatives volatility indices dip to 18-month compressed levels as options traders price in post-halving seasonal strength.',
    sentiment: 'Bullish',
    category: 'Macro',
    readTime: '5 min',
  },
];

// Generates candlestick chart matching the screenshot curve:
// Starts high around 77,200 - 77,400 at 06:00, sells down to 76,500 at 12:00, then sharp green rebound to 77,157.01
export function generateCandlesForPair(pair: string, count = 48): Candle[] {
  const isBtc = pair.includes('BTC');
  const basePrice = isBtc ? 77157.01 : pair.includes('ETH') ? 2494.2 : 100.4;
  const candles: Candle[] = [];
  const now = Date.now();
  const stepMs = 15 * 60 * 1000; // 15-minute candles

  // Shape profile multipliers over 48 candles:
  // Starts around +0.4%, dips down to -1.1% midway, then recovers to 0.0%
  for (let i = count - 1; i >= 0; i--) {
    const t = count - 1 - i; // 0 to count-1
    const normalized = t / (count - 1); // 0.0 to 1.0

    let curveOffset = 0;
    if (normalized < 0.25) {
      // High start
      curveOffset = 0.003 * Math.cos(normalized * Math.PI * 4);
    } else if (normalized >= 0.25 && normalized < 0.65) {
      // Deep red plunge towards 12:00
      const dipNorm = (normalized - 0.25) / 0.4;
      curveOffset = 0.002 - 0.010 * Math.sin(dipNorm * Math.PI);
    } else {
      // Sharp recovery rally back to current price
      const rallyNorm = (normalized - 0.65) / 0.35;
      curveOffset = -0.008 + 0.008 * Math.sin(rallyNorm * (Math.PI / 2));
    }

    const noise = (Math.sin(t * 1.7) * 0.0015) + (Math.cos(t * 0.8) * 0.001);
    const close = basePrice * (1 + curveOffset + (t === count - 1 ? 0 : noise));
    const open = t === 0 ? close * 0.999 : candles[candles.length - 1]?.close || close * 0.999;
    const high = Math.max(open, close) * (1 + Math.random() * 0.0025);
    const low = Math.min(open, close) * (1 - Math.random() * 0.0025);
    const volume = Math.floor(Math.random() * 850 + 150);

    const timestamp = now - i * stepMs;
    const dateObj = new Date(timestamp);
    const hours = dateObj.getHours().toString().padStart(2, '0');
    const minutes = dateObj.getMinutes().toString().padStart(2, '0');

    candles.push({
      time: `${hours}:${minutes}`,
      timestamp,
      open: parseFloat(open.toFixed(2)),
      high: parseFloat(high.toFixed(2)),
      low: parseFloat(low.toFixed(2)),
      close: parseFloat(close.toFixed(2)),
      volume,
    });
  }

  // Ensure last close matches exact price
  candles[candles.length - 1].close = basePrice;
  return candles;
}

export const TOP_STRATEGIES: TradingStrategy[] = [
  {
    id: 'strat-1',
    name: 'Dynamic Volatility Breakout (Vortex 2.0)',
    author: 'QuantCore Labs',
    tagline: 'Exploits high-probability ATR expansions following low-volatility squeezes.',
    indicator: 'Bollinger Band Pinch + RSI Divergence',
    winRate: 74.2,
    apy: 148.5,
    tradesCount: 428,
    profitFactor: 2.82,
    isProOnly: true,
    isActive: true,
    createdAt: '3 days ago',
  },
  {
    id: 'strat-2',
    name: 'EMA Cross Trend Rider',
    author: 'Aetheris Alpha',
    tagline: 'Captures sustained directional trends on 15M/1H charts with trailing stops.',
    indicator: 'EMA 21/55 Dynamic Golden Cross',
    winRate: 68.9,
    apy: 112.4,
    tradesCount: 615,
    profitFactor: 2.35,
    isProOnly: true,
    isActive: false,
    createdAt: '1 week ago',
  },
  {
    id: 'strat-3',
    name: 'Spot & Perp Funding Rate Arbitrage',
    author: 'NeutralDelta',
    tagline: 'Market-neutral yield harvesting by capturing positive perpetual funding spreads.',
    indicator: 'Funding Delta Oscillator',
    winRate: 92.4,
    apy: 38.6,
    tradesCount: 1840,
    profitFactor: 4.10,
    isProOnly: true,
    isActive: false,
    createdAt: '2 weeks ago',
  },
  {
    id: 'strat-4',
    name: 'Liquidity Wick Reversal Hunter',
    author: 'SMC Quant',
    tagline: 'Detects stop-run spikes into high-timeframe order blocks for high-RR fades.',
    indicator: 'Fair Value Gap (FVG) + CVD Rejection',
    winRate: 64.5,
    apy: 189.0,
    tradesCount: 312,
    profitFactor: 3.15,
    isProOnly: true,
    isActive: false,
    createdAt: 'Yesterday',
  },
];
